'use client';

import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Brain, Trophy, AlertTriangle, ArrowRight, RotateCcw, Sparkles, CheckCircle2 } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

const questions = [
  { id: 1, question: 'Do you have health insurance?', options: [{ label: 'Yes ✅', value: 33 }, { label: 'No ❌', value: 0 }, { label: 'Only employer-provided 🏢', value: 15 }] },
  { id: 2, question: 'Do you have life insurance?', options: [{ label: 'Yes ✅', value: 33 }, { label: 'No ❌', value: 0 }] },
  { id: 3, question: 'Is your motor insurance comprehensive?', options: [{ label: 'Yes, comprehensive 🛡️', value: 34 }, { label: 'No, not insured ❌', value: 0 }, { label: 'Third-party only 📄', value: 15 }] },
];

export default function GamifiedQuizSection() {
  const [currentQ, setCurrentQ] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [showResult, setShowResult] = useState(false);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);

  const score = answers.reduce((a, b) => a + b, 0);
  const progress = ((currentQ + (showResult ? 1 : 0)) / questions.length) * 100;

  const handleAnswer = useCallback((value: number) => {
    setSelectedOption(value);
    setTimeout(() => {
      const newAnswers = [...answers, value];
      setAnswers(newAnswers);
      setSelectedOption(null);
      if (currentQ < questions.length - 1) { setCurrentQ((p) => p + 1); }
      else { setShowResult(true); }
    }, 400);
  }, [answers, currentQ]);

  const resetQuiz = useCallback(() => { setCurrentQ(0); setAnswers([]); setShowResult(false); setSelectedOption(null); }, []);

  const getScoreMsg = (s: number) => {
    if (s >= 90) return { emoji: '🏆', msg: 'Excellent! You\'re well-protected!', color: 'text-green-500' };
    if (s >= 60) return { emoji: '👍', msg: 'Good coverage, but some gaps exist.', color: 'text-amber-500' };
    if (s >= 30) return { emoji: '⚠️', msg: 'You have some gaps. Get a personalized plan →', color: 'text-orange-500' };
    return { emoji: '🚨', msg: 'You\'re underinsured! Let us help you now.', color: 'text-red-500' };
  };
  const scoreInfo = getScoreMsg(score);

  return (
    <section id="insurance-quiz" className="py-16 sm:py-24 bg-gradient-to-b from-slate-50 via-white to-background dark:from-[#0c1322] dark:via-[#111b33] dark:to-background scroll-mt-16">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-10">
          <Badge className="mb-4 bg-teal-50 text-teal-700 border-teal-200 dark:bg-teal-950/50 dark:text-teal-300 dark:border-teal-800 rounded-full px-4 py-1"><Brain className="w-3.5 h-3.5 mr-1" />Quick Quiz</Badge>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-foreground dark:text-white tracking-tight">How Insured <span className="text-teal-700 dark:text-[#00A9A6]">Are You?</span></h2>
          <p className="mt-3 text-sm sm:text-base text-muted-foreground">Answer 3 quick questions to check your insurance coverage score</p>
        </motion.div>

        {/* Progress */}
        <div className="mb-6">
          <div className="flex items-center justify-between text-xs text-muted-foreground mb-2">
            <span>Question {Math.min(currentQ + 1, questions.length)} of {questions.length}</span>
            <span>{Math.round(progress)}% complete</span>
          </div>
          <div className="h-2 bg-slate-200 dark:bg-white/10 rounded-full overflow-hidden">
            <motion.div className="h-full bg-gradient-to-r from-[#00A9A6] to-teal-400 rounded-full" initial={{ width: 0 }} animate={{ width: `${progress}%` }} transition={{ duration: 0.5 }} />
          </div>
        </div>

        <AnimatePresence mode="wait">
          {!showResult ? (
            <motion.div key={`q-${currentQ}`} initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -50 }} transition={{ duration: 0.3 }}>
              <Card className="bg-white/80 border-slate-200/60 shadow-sm backdrop-blur-xl dark:bg-white/10 dark:border-white/20 rounded-3xl">
                <CardContent className="pt-6 space-y-3">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="w-8 h-8 rounded-full bg-teal-50 text-teal-700 dark:bg-[#00A9A6]/20 dark:text-[#00A9A6] flex items-center justify-center text-sm font-bold">{currentQ + 1}</span>
                    <p className="text-foreground dark:text-white text-lg font-semibold">{questions[currentQ].question}</p>
                  </div>
                  {questions[currentQ].options.map((option) => (
                    <motion.button key={option.value} whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} onClick={() => handleAnswer(option.value)}
                      className={`w-full text-left p-4 rounded-2xl border-2 transition-all duration-200 min-h-[48px] ${selectedOption === option.value ? 'border-teal-400 bg-teal-50 text-foreground dark:border-teal-600 dark:bg-teal-950/40 dark:text-white' : 'border-slate-200 bg-slate-50 text-foreground dark:border-white/10 dark:bg-white/5 dark:text-slate-200 hover:border-[#00A9A6]/40 hover:bg-slate-100 dark:hover:bg-white/10'}`}>
                      <span className="text-sm font-medium">{option.label}</span>
                    </motion.button>
                  ))}
                </CardContent>
              </Card>
            </motion.div>
          ) : (
            <motion.div key="result" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.5 }}>
              <Card className="bg-white/80 border-slate-200/60 shadow-sm backdrop-blur-xl dark:bg-white/10 dark:border-white/20 rounded-3xl text-center">
                <CardContent className="pt-8 pb-8 space-y-6">
                  <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.2, type: 'spring' as const, stiffness: 200 }} className="inline-flex items-center justify-center">
                    <div className="w-36 h-36 rounded-full border-4 border-[#00A9A6]/30 flex items-center justify-center relative overflow-hidden">
                      <motion.div initial={{ height: 0 }} animate={{ height: `${score}%` }} transition={{ delay: 0.5, duration: 1 }} className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-[#00A9A6]/20 to-transparent" />
                      <div className="relative z-10">
                        <p className="text-4xl font-extrabold text-foreground dark:text-white">{score}</p>
                        <p className="text-xs text-muted-foreground">out of 100</p>
                      </div>
                    </div>
                  </motion.div>
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.8 }}>
                    <p className="text-3xl mb-2">{scoreInfo.emoji}</p>
                    <p className={`text-lg font-semibold ${scoreInfo.color}`}>{scoreInfo.msg}</p>
                  </motion.div>
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1 }} className="space-y-2 text-left max-w-xs mx-auto">
                    {questions.map((q, i) => (
                      <div key={q.id} className="flex items-center gap-2 text-sm">
                        {answers[i] >= 30 ? <CheckCircle2 className="w-4 h-4 text-green-500 dark:text-green-400 shrink-0" /> : <AlertTriangle className="w-4 h-4 text-amber-500 dark:text-amber-400 shrink-0" />}
                        <span className="text-muted-foreground">{q.question.replace('?', '')}: {q.options.find(o => o.value === answers[i])?.label || 'N/A'}</span>
                      </div>
                    ))}
                  </motion.div>
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.2 }} className="flex flex-col sm:flex-row items-center justify-center gap-3">
                    <Button onClick={resetQuiz} variant="outline" className="border-border text-foreground dark:border-white/20 dark:text-white hover:bg-slate-100 dark:hover:bg-white/10 rounded-full gap-2"><RotateCcw className="w-4 h-4" />Retake Quiz</Button>
                    <Button className="bg-gradient-to-r from-[#00A9A6] to-teal-500 text-white rounded-full gap-2 shadow-lg shadow-[#00A9A6]/25"><Sparkles className="w-4 h-4" />Get Personalized Plan<ArrowRight className="w-4 h-4" /></Button>
                  </motion.div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="flex items-center justify-center gap-2 mt-6">
          {questions.map((_, i) => (
            <div key={i} className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${i < currentQ || showResult ? 'bg-[#00A9A6]' : i === currentQ ? 'bg-[#00A9A6]/60 scale-125' : 'bg-slate-300 dark:bg-white/20'}`} />
          ))}
        </div>
      </div>
    </section>
  );
}
