'use client';

import { Shield, Clock, AlertCircle, RefreshCw } from 'lucide-react';
import { motion } from 'framer-motion';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';

const rights = [
  {
    icon: Shield,
    title: 'IRDAI Moratorium Clause',
    color: 'text-blue-600 dark:text-blue-400',
    iconBg: 'bg-blue-100 dark:bg-blue-900/40',
    borderColor: 'border-blue-200 dark:border-blue-800/40',
    content: (
      <>
        <p className="text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
          After 5 continuous years of coverage, no claim rejection for
          non-disclosure — except in cases of proven fraud.
        </p>
        <p className="text-xs text-slate-400 dark:text-slate-500 mt-2">
          Source: IRDAI Regulations 2025-26
        </p>
      </>
    ),
  },
  {
    icon: Clock,
    title: 'Cashless Claim Timelines',
    color: 'text-teal-700 dark:text-[#00A9A6]',
    iconBg: 'bg-teal-100 dark:bg-teal-900/40',
    borderColor: 'border-teal-200 dark:border-teal-800/40',
    content: (
      <ul className="space-y-2">
        <li className="flex items-start gap-2 text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
          <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-teal-700 dark:bg-[#00A9A6]" />
          Pre-authorisation within <strong className="text-slate-800 dark:text-white">1 hour</strong> of document receipt
        </li>
        <li className="flex items-start gap-2 text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
          <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-teal-700 dark:bg-[#00A9A6]" />
          Discharge approval within <strong className="text-slate-800 dark:text-white">3 hours</strong> of final bill
        </li>
        <li className="text-xs text-slate-400 dark:text-slate-500 mt-2">
          Mandated by IRDAI
        </li>
      </ul>
    ),
  },
  {
    icon: AlertCircle,
    title: 'How to Appeal a Rejected Claim',
    color: 'text-amber-600 dark:text-amber-400',
    iconBg: 'bg-amber-100 dark:bg-amber-900/40',
    borderColor: 'border-amber-200 dark:border-amber-800/40',
    content: (
      <ol className="space-y-2.5">
        <li className="flex items-start gap-2.5 text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
          <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-amber-100 dark:bg-amber-900/40 text-xs font-semibold text-amber-700 dark:text-amber-300">
            1
          </span>
          <span>
            <strong className="text-slate-800 dark:text-white">Grievance Redressal Officer</strong> — Insurer&apos;s internal escalation
          </span>
        </li>
        <li className="flex items-start gap-2.5 text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
          <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-amber-100 dark:bg-amber-900/40 text-xs font-semibold text-amber-700 dark:text-amber-300">
            2
          </span>
          <span>
            <strong className="text-slate-800 dark:text-white">Bima Bharosa Portal</strong> — IRDAI&apos;s online platform for consumer complaints
          </span>
        </li>
        <li className="flex items-start gap-2.5 text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
          <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-amber-100 dark:bg-amber-900/40 text-xs font-semibold text-amber-700 dark:text-amber-300">
            3
          </span>
          <span>
            <strong className="text-slate-800 dark:text-white">Insurance Ombudsman</strong> — For claims up to ₹50L
          </span>
        </li>
      </ol>
    ),
  },
  {
    icon: RefreshCw,
    title: 'Right to Portability',
    color: 'text-green-600 dark:text-green-400',
    iconBg: 'bg-green-100 dark:bg-green-900/40',
    borderColor: 'border-green-200 dark:border-green-800/40',
    content: (
      <>
        <p className="text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
          You can switch insurers without resetting PED (Pre-Existing Disease) waiting periods. IRDAI mandates seamless portability — your continuity of coverage is protected.
        </p>
      </>
    ),
  },
];

const cardVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.45,
      delay: 0.1 * i,
      ease: 'easeOut' as const,
    },
  }),
};

export default function PolicyholderRightsSection() {
  return (
    <motion.section
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: 'easeOut' as const }}
      className="space-y-6"
    >
      <div className="flex items-center gap-2">
        <Shield className="h-5 w-5 text-teal-700 dark:text-[#00A9A6]" />
        <h2 className="text-lg font-semibold text-slate-800 dark:text-white">
          Policyholder Rights &amp; Regulations
        </h2>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        {rights.map((right, index) => {
          const Icon = right.icon;
          return (
            <motion.div
              key={right.title}
              custom={index}
              initial="hidden"
              animate="visible"
              variants={cardVariants}
            >
              <Card className={`h-full ${right.borderColor}`}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2.5">
                    <div
                      className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${right.iconBg}`}
                    >
                      <Icon className={`h-5 w-5 ${right.color}`} />
                    </div>
                    <span className="text-sm text-slate-800 dark:text-white">
                      {right.title}
                    </span>
                  </CardTitle>
                </CardHeader>
                <CardContent>{right.content}</CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.7 }}
        className="text-xs text-center text-slate-400 dark:text-slate-500"
      >
        Based on IRDAI regulations 2025-26. For detailed terms, refer to your
        policy document.
      </motion.p>
    </motion.section>
  );
}
