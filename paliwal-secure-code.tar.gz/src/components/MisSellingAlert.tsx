'use client';

import { useState, useEffect } from 'react';
import { AlertTriangle, X, Info, Shield, Banknote, Users, TrendingUp } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { motion, AnimatePresence } from 'framer-motion';

// ============================================
// DATA (Source: IRDAI, Insurance Samadhan, ED Reports)
// ============================================

const misSellingStats = {
  totalBankCommission: 21773, // ₹ Crore (FY24, Top 15 banks)
  highestBankCommission: { name: 'HDFC Bank', amount: 6467 },
  misSellingComplaintsIncrease: 11.2, // YoY %
  healthMisSellingShare: 68, // % of total mis-selling complaints
  lifeMisSellingShare: 25.5,
  estimatedFraudClaims: '10-15%', // industry estimate
  majorFraudCase: { amount: 500, location: 'Uttar Pradesh', description: 'Forged documents scam' },
  ageGroupMostAffected: '31-40 years',
  topStateComplaints: 'Uttar Pradesh (16%)',
  bankEarningsShare: { bank: 'Axis Bank', share: 25.2 }, // commission as % of earnings
  policyLapseRate: 43.3, // % of benefits paid due to churning
};

// Tips to avoid mis-selling
const preventionTips = [
  'Always read the policy document carefully before signing',
  'Ask the agent to explain all exclusions and waiting periods',
  'Do not buy insurance solely for tax savings \u2013 check coverage first',
  'Verify agent\'s IRDAI license number on the official portal',
  'Use the free-look period (15-30 days) to cancel if not satisfied',
  'Compare similar plans from at least 3 different insurers',
  'Never share OTP or sign blank proposal forms',
];

// Red flags to watch for
const redFlags = [
  'Guaranteed returns or "investment" promises',
  'Pressure to buy immediately (limited time offer)',
  'Agent discourages reading policy document',
  'Combining insurance with investment as "free"',
  'Unusually high commissions mentioned',
  'Policy terms not explained in your preferred language',
];

export default function MisSellingAlert() {
  const [isVisible, setIsVisible] = useState(true);
  const [activeTab, setActiveTab] = useState<'alert' | 'tips' | 'redflags'>('alert');

  if (!isVisible) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: 'easeOut' as const }}
    >
      <Card className="border-orange-200 dark:border-orange-800/40 bg-gradient-to-r from-orange-50 to-amber-50 dark:from-orange-950/30 dark:to-amber-950/30 shadow-lg">
        <CardContent className="p-4 md:p-6">
          {/* Header with close button */}
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-6 w-6 text-orange-600 dark:text-orange-400" />
              <h3 className="text-lg font-bold text-orange-800 dark:text-orange-300">
                Insurance Mis-selling Alert
              </h3>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6 text-muted-foreground hover:text-foreground"
              onClick={() => setIsVisible(false)}
              aria-label="Dismiss alert"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>

          {/* Tab navigation */}
          <div className="flex flex-wrap gap-2 mb-4 border-b border-orange-200 dark:border-orange-800/30 pb-2">
            <button
              onClick={() => setActiveTab('alert')}
              className={`px-3 py-1.5 text-sm rounded-lg transition-colors ${
                activeTab === 'alert'
                  ? 'bg-orange-600 text-white'
                  : 'bg-orange-100 dark:bg-orange-900/50 text-orange-700 dark:text-orange-300 hover:bg-orange-200 dark:hover:bg-orange-900/70'
              }`}
            >
              Key Statistics
            </button>
            <button
              onClick={() => setActiveTab('tips')}
              className={`px-3 py-1.5 text-sm rounded-lg transition-colors ${
                activeTab === 'tips'
                  ? 'bg-orange-600 text-white'
                  : 'bg-orange-100 dark:bg-orange-900/50 text-orange-700 dark:text-orange-300 hover:bg-orange-200 dark:hover:bg-orange-900/70'
              }`}
            >
              Prevention Tips
            </button>
            <button
              onClick={() => setActiveTab('redflags')}
              className={`px-3 py-1.5 text-sm rounded-lg transition-colors ${
                activeTab === 'redflags'
                  ? 'bg-orange-600 text-white'
                  : 'bg-orange-100 dark:bg-orange-900/50 text-orange-700 dark:text-orange-300 hover:bg-orange-200 dark:hover:bg-orange-900/70'
              }`}
            >
              Red Flags
            </button>
          </div>

          {/* Tab content */}
          <AnimatePresence mode="wait">
            {activeTab === 'alert' && (
              <motion.div
                key="alert"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                transition={{ duration: 0.25 }}
                className="space-y-4"
              >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="flex items-start gap-2 p-2 bg-white/50 dark:bg-black/20 rounded-lg">
                    <Banknote className="h-5 w-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs text-muted-foreground">Top 15 Banks&apos; Insurance Commission (FY24)</p>
                      <p className="font-bold text-lg text-slate-800 dark:text-white">
                        ₹{misSellingStats.totalBankCommission.toLocaleString()} Crore
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        HDFC Bank alone: ₹{misSellingStats.highestBankCommission.amount} Cr
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2 p-2 bg-white/50 dark:bg-black/20 rounded-lg">
                    <TrendingUp className="h-5 w-5 text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs text-muted-foreground">Mis-selling Complaints (YoY)</p>
                      <p className="font-bold text-lg text-slate-800 dark:text-white">
                        +{misSellingStats.misSellingComplaintsIncrease}%
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        Health insurance accounts for 68% of complaints
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2 p-2 bg-white/50 dark:bg-black/20 rounded-lg">
                    <Users className="h-5 w-5 text-purple-600 dark:text-purple-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs text-muted-foreground">Most Affected Age Group</p>
                      <p className="font-bold text-lg text-slate-800 dark:text-white">
                        {misSellingStats.ageGroupMostAffected}
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        Young adults are most proactive, hence targeted
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2 p-2 bg-white/50 dark:bg-black/20 rounded-lg">
                    <Shield className="h-5 w-5 text-green-600 dark:text-green-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs text-muted-foreground">Estimated Fraudulent Claims</p>
                      <p className="font-bold text-lg text-slate-800 dark:text-white">
                        {misSellingStats.estimatedFraudClaims}
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        Industry-wide estimate; ₹500 Cr scam in UP exposed
                      </p>
                    </div>
                  </div>
                </div>
                <div className="text-xs text-muted-foreground border-t border-orange-200 dark:border-orange-800/30 pt-3 mt-2">
                  <p className="flex items-start gap-1">
                    <Info className="h-3 w-3 mt-0.5 flex-shrink-0" />
                    <span>
                      Source: IRDAI Annual Report, Insurance Samadhan, Enforcement Directorate. Bank commissions are legal but can lead to mis-selling pressure.
                    </span>
                  </p>
                </div>
              </motion.div>
            )}

            {activeTab === 'tips' && (
              <motion.div
                key="tips"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                transition={{ duration: 0.25 }}
                className="space-y-2"
              >
                <ul className="list-disc list-inside space-y-1.5 text-sm">
                  {preventionTips.map((tip, idx) => (
                    <li key={idx} className="text-slate-700 dark:text-slate-300">{tip}</li>
                  ))}
                </ul>
                <div className="mt-3 p-2 bg-green-50 dark:bg-green-950/30 rounded-lg text-sm">
                  <strong>Pro Tip:</strong> Always check the insurer&apos;s Claim Settlement Ratio (CSR) and complaint data on our{' '}
                  <a href="/claims-dashboard" className="text-blue-600 dark:text-blue-400 underline hover:text-blue-800 dark:hover:text-blue-300">
                    Claims Dashboard
                  </a>{' '}
                  before buying.
                </div>
              </motion.div>
            )}

            {activeTab === 'redflags' && (
              <motion.div
                key="redflags"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                transition={{ duration: 0.25 }}
                className="space-y-2"
              >
                <ul className="list-disc list-inside space-y-1.5 text-sm">
                  {redFlags.map((flag, idx) => (
                    <li key={idx} className="text-red-700 dark:text-red-300">{flag}</li>
                  ))}
                </ul>
                <div className="mt-3 p-2 bg-red-50 dark:bg-red-950/30 rounded-lg text-sm">
                  <strong>If you notice any red flag:</strong> Do not proceed. Use IRDAI&apos;s Bima Bharosa portal to register a complaint or call{' '}
                  <span className="font-semibold">1800-258-1111</span> (IRDAI helpline).
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </CardContent>
      </Card>
    </motion.div>
  );
}
