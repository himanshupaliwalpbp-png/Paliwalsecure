'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Shield,
  Clock,
  FileCheck,
  Phone,
  Mail,
  AlertCircle,
  CheckCircle,
  Scale,
  Users,
  Building2,
  ExternalLink,
} from 'lucide-react';
import { motion } from 'framer-motion';
import Link from 'next/link';

// ============================================
// DATA (Source: IRDAI Regulations 2025-26)
// ============================================

const rightsData = [
  {
    title: '30-Day Free Look Period',
    description: 'You can cancel your policy within 15-30 days of receiving it if not satisfied. Full refund after deducting stamp duty and proportionate risk premium.',
    icon: Clock,
    color: 'text-blue-600 dark:text-blue-400',
    bg: 'bg-blue-50 dark:bg-blue-950/30',
    border: 'border-blue-200 dark:border-blue-800/30',
  },
  {
    title: 'Moratorium Period (5 Years)',
    description: 'After 5 continuous years of policy, no claim can be rejected for non-disclosure (except fraud). This is reduced from 8 years in 2025.',
    icon: Shield,
    color: 'text-green-600 dark:text-green-400',
    bg: 'bg-green-50 dark:bg-green-950/30',
    border: 'border-green-200 dark:border-green-800/30',
  },
  {
    title: 'Portability Right',
    description: 'You can switch insurers without losing accrued benefits (waiting period, no claim bonus). New insurer cannot impose fresh waiting periods for existing conditions.',
    icon: Users,
    color: 'text-purple-600 dark:text-purple-400',
    bg: 'bg-purple-50 dark:bg-purple-950/30',
    border: 'border-purple-200 dark:border-purple-800/30',
  },
  {
    title: 'Claim Settlement Timeline',
    description: 'Insurers must settle claims within 30 days of receiving all documents. Cashless pre-authorisation within 1 hour, discharge within 3 hours (IRDAI mandate).',
    icon: Clock,
    color: 'text-orange-600 dark:text-orange-400',
    bg: 'bg-orange-50 dark:bg-orange-950/30',
    border: 'border-orange-200 dark:border-orange-800/30',
  },
  {
    title: 'Grievance Redressal',
    description: 'Every insurer has an internal ombudsman. You can escalate to IRDAI Bima Bharosa portal or Insurance Ombudsman (free, for claims up to \u20B950 lakh).',
    icon: Scale,
    color: 'text-red-600 dark:text-red-400',
    bg: 'bg-red-50 dark:bg-red-950/30',
    border: 'border-red-200 dark:border-red-800/30',
  },
  {
    title: 'Nomination & Assignment',
    description: 'You can nominate beneficiaries. Assignment allows transferring policy ownership. Both are your legal rights.',
    icon: FileCheck,
    color: 'text-teal-600 dark:text-teal-400',
    bg: 'bg-teal-50 dark:bg-teal-950/30',
    border: 'border-teal-200 dark:border-teal-800/30',
  },
];

const appealSteps = [
  {
    step: 1,
    title: 'Contact Insurer Grievance Cell',
    description: 'First, raise a complaint with the insurer\'s internal grievance redressal officer. Most issues resolved here within 15 days.',
    contact: 'Find on insurer\'s website under "Grievance Redressal"',
  },
  {
    step: 2,
    title: 'Escalate to IRDAI Bima Bharosa Portal',
    description: 'If not satisfied, register complaint on IRDAI\'s centralized portal. Insurers must respond within 15 days.',
    contact: 'https://bimabharosa.irda.gov.in | Toll-free: 1800-258-1111',
  },
  {
    step: 3,
    title: 'Approach Insurance Ombudsman',
    description: 'For claims up to \u20B950 lakh, you can file a complaint with the Insurance Ombudsman (free service). Award binding on insurer.',
    contact: '12 offices across India. Find nearest on IRDAI website.',
  },
  {
    step: 4,
    title: 'Consumer Court / Legal Action',
    description: 'If ombudsman fails or claim exceeds \u20B950 lakh, approach District/State/National Consumer Disputes Redressal Commission.',
    contact: 'Legal assistance may be required; document all correspondence.',
  },
];

const irdaTimelines = [
  { rule: 'Cashless pre-authorisation decision', timeline: 'Within 1 hour of receiving documents' },
  { rule: 'Discharge approval (final bill)', timeline: 'Within 3 hours of submission' },
  { rule: 'Claim settlement (reimbursement)', timeline: 'Within 30 days of all documents' },
  { rule: 'Grievance acknowledgement', timeline: 'Within 3 working days' },
  { rule: 'Grievance resolution (insurer level)', timeline: 'Within 15 days' },
];

const keyRegulations = [
  'PED Waiting Period capped at 3 years (max) \u2013 IRDAI 2025',
  'No upper age limit for buying health insurance \u2013 insurers must offer at least one plan',
  'Lifelong renewability guaranteed for all retail health policies',
  '100% cashless claims mandate \u2013 insurers cannot deny cashless facility',
  'Penalty on insurers for delays (from shareholders\' funds)',
];

// ============================================
// ANIMATION VARIANTS
// ============================================

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: 'easeOut' as const } },
};

// ============================================
// MAIN COMPONENT
// ============================================

export default function PolicyholderRightsPage() {
  return (
    <div className="min-h-screen bg-background">
      <motion.div
        className="container mx-auto px-4 py-8 max-w-6xl"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Back link */}
        <motion.div variants={itemVariants} className="mb-4">
          <Link
            href="/"
            className="inline-flex items-center gap-1.5 text-sm text-slate-500 dark:text-slate-400 hover:text-teal-700 dark:hover:text-[#00A9A6] transition-colors"
          >
            <span>&larr;</span> Back to Home
          </Link>
        </motion.div>

        {/* Header */}
        <motion.div variants={itemVariants} className="mb-8 text-center">
          <h1 className="text-3xl md:text-4xl font-bold text-slate-800 dark:text-white">
            Your Insurance Rights
          </h1>
          <p className="text-slate-500 dark:text-slate-400 mt-2 max-w-2xl mx-auto">
            Know your rights as a policyholder under IRDAI regulations. If your claim is rejected unfairly, you have legal protection.
          </p>
        </motion.div>

        {/* Rights Grid */}
        <motion.div
          variants={containerVariants}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12"
        >
          {rightsData.map((right, idx) => {
            const Icon = right.icon;
            return (
              <motion.div key={idx} variants={itemVariants} whileHover={{ y: -4 }}>
                <Card className={`h-full ${right.border} hover:shadow-lg transition-shadow bg-white/90 dark:bg-white/10 backdrop-blur-sm`}>
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <div className={`rounded-lg p-2 ${right.bg}`}>
                        <Icon className={`h-5 w-5 ${right.color}`} />
                      </div>
                      <CardTitle className="text-lg text-slate-800 dark:text-white">{right.title}</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-slate-600 dark:text-slate-400">{right.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Tabs for Detailed Info */}
        <motion.div variants={itemVariants}>
          <Tabs defaultValue="appeal" className="mb-12">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="appeal">Claim Rejection Appeal</TabsTrigger>
              <TabsTrigger value="timeline">IRDAI Timelines</TabsTrigger>
              <TabsTrigger value="regulations">Key Regulations</TabsTrigger>
            </TabsList>

            {/* Tab 1: Appeal Process */}
            <TabsContent value="appeal">
              <Card className="bg-white/90 dark:bg-white/10 border-slate-200 dark:border-white/10 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-slate-800 dark:text-white">
                    Step-by-Step: How to Appeal a Rejected Claim
                  </CardTitle>
                  <CardDescription className="text-slate-500 dark:text-slate-400">
                    Follow these steps if your insurance claim is rejected or delayed unreasonably.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {appealSteps.map((step) => (
                      <div key={step.step} className="flex gap-4">
                        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-teal-700/10 dark:bg-[#00A9A6]/20 text-teal-700 dark:text-[#00A9A6] flex items-center justify-center font-bold text-sm">
                          {step.step}
                        </div>
                        <div>
                          <h3 className="font-semibold text-slate-800 dark:text-white">{step.title}</h3>
                          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">{step.description}</p>
                          <p className="text-xs text-blue-600 dark:text-blue-400 mt-1">
                            {step.contact}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="mt-6 p-3 bg-amber-50 dark:bg-amber-950/30 rounded-lg text-sm border border-amber-200 dark:border-amber-800/30">
                    <AlertCircle className="inline h-4 w-4 text-amber-600 dark:text-amber-400 mr-1" />
                    <strong className="text-amber-800 dark:text-amber-300">Important:</strong>{' '}
                    <span className="text-slate-700 dark:text-slate-300">
                      Always keep copies of all correspondence, claim forms, medical reports, and the insurer&apos;s rejection letter. These are essential for appeal.
                    </span>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Tab 2: IRDAI Timelines */}
            <TabsContent value="timeline">
              <Card className="bg-white/90 dark:bg-white/10 border-slate-200 dark:border-white/10 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-slate-800 dark:text-white">
                    Insurer Response Timelines (IRDAI Mandated)
                  </CardTitle>
                  <CardDescription className="text-slate-500 dark:text-slate-400">
                    Insurers must adhere to these timelines; delays can be reported to IRDAI.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-slate-200 dark:border-white/10">
                          <th className="text-left py-3 px-2 font-semibold text-slate-800 dark:text-white">Process / Action</th>
                          <th className="text-left py-3 px-2 font-semibold text-slate-800 dark:text-white">Maximum Timeline</th>
                        </tr>
                      </thead>
                      <tbody>
                        {irdaTimelines.map((item, idx) => (
                          <tr key={idx} className="border-b border-slate-100 dark:border-white/5 hover:bg-slate-50 dark:hover:bg-white/5 transition-colors">
                            <td className="py-3 px-2 text-slate-700 dark:text-slate-300">{item.rule}</td>
                            <td className="py-3 px-2 font-medium text-green-600 dark:text-green-400">{item.timeline}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <div className="mt-4 text-xs text-slate-400 dark:text-slate-500">
                    Source: IRDAI (Insurance Regulatory and Development Authority of India) circulars 2025-26.
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Tab 3: Key Regulations */}
            <TabsContent value="regulations">
              <Card className="bg-white/90 dark:bg-white/10 border-slate-200 dark:border-white/10 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-slate-800 dark:text-white">
                    Recent IRDAI Regulations (2025-26)
                  </CardTitle>
                  <CardDescription className="text-slate-500 dark:text-slate-400">
                    These changes strengthen policyholder protection.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {keyRegulations.map((reg, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-slate-700 dark:text-slate-300">
                        <CheckCircle className="h-5 w-5 text-green-600 dark:text-green-400 flex-shrink-0 mt-0.5" />
                        <span>{reg}</span>
                      </li>
                    ))}
                  </ul>
                  <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-950/30 rounded-lg border border-blue-200 dark:border-blue-800/30">
                    <p className="text-sm flex items-start gap-2 text-slate-700 dark:text-slate-300">
                      <Building2 className="h-4 w-4 text-blue-600 dark:text-blue-400 mt-0.5 flex-shrink-0" />
                      <span>Insurers must now maintain an <strong>internal ombudsman</strong> to resolve disputes up to {'\u20B9'}50 lakh. This is mandatory from July 2025.</span>
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>

        {/* Helpful Resources */}
        <motion.div variants={itemVariants}>
          <Card className="mb-8 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950/30 dark:to-indigo-950/30 border-blue-200 dark:border-blue-800/30">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-slate-800 dark:text-white">
                <Phone className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                Where to Get Help?
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div className="flex items-start gap-2">
                  <Mail className="h-4 w-4 text-blue-600 dark:text-blue-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <strong className="text-slate-800 dark:text-white">Bima Bharosa Portal</strong>
                    <p className="text-slate-500 dark:text-slate-400">https://bimabharosa.irda.gov.in</p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <Phone className="h-4 w-4 text-blue-600 dark:text-blue-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <strong className="text-slate-800 dark:text-white">IRDAI Toll-Free Helpline</strong>
                    <p className="text-slate-500 dark:text-slate-400">1800-258-1111</p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <ExternalLink className="h-4 w-4 text-blue-600 dark:text-blue-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <strong className="text-slate-800 dark:text-white">Ombudsman Offices</strong>
                    <p className="text-slate-500 dark:text-slate-400">Find nearest office on IRDAI website</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Related Pages */}
        <motion.div variants={itemVariants}>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
            <Link href="/claims-dashboard">
              <Card className="hover:shadow-lg transition-all hover:-translate-y-1 bg-white/90 dark:bg-white/10 border-slate-200 dark:border-white/10 cursor-pointer h-full">
                <CardContent className="p-4 text-center">
                  <Shield className="h-8 w-8 text-teal-700 dark:text-[#00A9A6] mx-auto mb-2" />
                  <h3 className="font-semibold text-sm text-slate-800 dark:text-white">Claims Dashboard</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">CSR & grievance data</p>
                </CardContent>
              </Card>
            </Link>
            <Link href="/">
              <Card className="hover:shadow-lg transition-all hover:-translate-y-1 bg-white/90 dark:bg-white/10 border-slate-200 dark:border-white/10 cursor-pointer h-full">
                <CardContent className="p-4 text-center">
                  <AlertCircle className="h-8 w-8 text-orange-600 dark:text-orange-400 mx-auto mb-2" />
                  <h3 className="font-semibold text-sm text-slate-800 dark:text-white">Mis-selling Alert</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Know the red flags</p>
                </CardContent>
              </Card>
            </Link>
            <Link href="/">
              <Card className="hover:shadow-lg transition-all hover:-translate-y-1 bg-white/90 dark:bg-white/10 border-slate-200 dark:border-white/10 cursor-pointer h-full">
                <CardContent className="p-4 text-center">
                  <Scale className="h-8 w-8 text-purple-600 dark:text-purple-400 mx-auto mb-2" />
                  <h3 className="font-semibold text-sm text-slate-800 dark:text-white">Industry Insights</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">IRDAI market data</p>
                </CardContent>
              </Card>
            </Link>
          </div>
        </motion.div>

        {/* Disclaimer */}
        <motion.div variants={itemVariants} className="text-center text-xs text-slate-400 dark:text-slate-500 border-t border-slate-200 dark:border-white/10 pt-6">
          <p>This information is for general awareness and based on IRDAI regulations (2025-26). For specific legal advice, consult a professional or contact IRDAI directly.</p>
          <p className="mt-1">Last updated: May 2026.</p>
        </motion.div>
      </motion.div>
    </div>
  );
}
